// import React, { useState } from 'react';
//import ReactDOM from "react-dom/client";
import {BrowserRouter, Routes, Route, Navigate} from "react-router-dom";
import Layout from "./pages/Layout";
import Home from "./pages/Home";
import Blogs from "./pages/Blogs";
import Contact from "./pages/Contact";
import UserList from "./pages/UserList";
import Authos from "./pages/Authos";
import FileUpload from "./pages/FileUpload";
import AdminDashboard from './pages/AdminDashboard'; 
 
import NoPage from "./pages/NoPage";
import './App.css';

function App() {
  return ( 
    <div className="App">
     <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout/>}>
          <Route index element={<Home/>} />
          <Route path="blogs" element={<Blogs/>} />
          <Route path="contact" element={<Contact/>} />
          <Route path="UserList" element={<UserList/>} />
          <Route path="FileUpload" element={<FileUpload/>} />
          <Route path="Authos" element={<Authos/>} />
          <Route
            path="admin"
            element={
              localStorage.getItem('token') ? (
                <AdminDashboard />
              ) : (
                <Navigate to="/Authos" />
              )
            }
          />
          <Route path="*" element={<NoPage/>} />
        </Route>
      </Routes> 
     </BrowserRouter>
    </div>
  ); 
}
export default App;