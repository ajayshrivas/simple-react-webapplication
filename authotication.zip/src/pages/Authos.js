import Login from "./components/Login";
import Register from "./components/Register";
import Logout from "./components/Logout";
function Authos() {
    return(
        <>
        <Login></Login>
        <Register></Register>
        <Logout></Logout>
        </>
       );
}
export default Authos; 