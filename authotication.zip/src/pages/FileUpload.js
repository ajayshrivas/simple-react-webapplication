import React, { useState } from 'react';

function FileUploader() {
  const [buffering, setBuffering] = useState(false);
  const [countdown, setCountdown] = useState(10); // Initial countdown time in seconds
  const [progress, setProgress] = useState(0); // File upload progress
  const [file, setFile] = useState(null);

  // Handle file selection
  const handleFileChange = (event) => {
    const selectedFile = event.target.files[0];
    setFile(selectedFile);
  };

  // Start buffering and countdown
  const startUpload = () => {
    setBuffering(true);

    const countdownInterval = setInterval(() => {
      setCountdown((prevCountdown) => prevCountdown - 1);
    }, 1000);

    setTimeout(() => {
      clearInterval(countdownInterval);
      setBuffering(false);
      uploadFile();
    }, countdown * 1000);
  };

  // Simulate file upload (you can replace this with your actual API call)
  const uploadFile = () => {
    // Simulate file upload progress
    const uploadInterval = setInterval(() => {
      setProgress((prevProgress) => {
        if (prevProgress >= 100) {
          clearInterval(uploadInterval);
          return 100;
        }
        return prevProgress + 10;
      });
    }, 1000);
  };

  return (
    <div>
      <input type="file" onChange={handleFileChange} />
      <button onClick={startUpload}>Start Upload</button>

      {buffering && (
        <div>
          Buffering... {countdown} seconds
        </div>
      )}

      {progress > 0 && progress < 100 && (
        <div>
          Uploading... {progress}% complete
        </div>
      )}

      {progress === 100 && <div>Upload complete!</div>}
    </div>
  );
}

export default FileUploader;
