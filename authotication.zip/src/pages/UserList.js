import React, { useState, useEffect } from 'react';

function UserList() {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    fetch('http://localhost:8000/api/selectUsers')
      .then((response) => response.json())
      .then((data) => setUsers(data));
  }, []);

  const handleDelete = (userId) => {
    const apiUrl = `http://localhost:8000/users/${userId}`; // Replace with your Node.js server URL

    fetch(apiUrl, {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json',
      },
    })
      .then((response) => {
        if (response.ok) {
          return response.json();
        } else {
          throw new Error('Failed to delete user');
        }
      })
      .then((data) => {
        console.log(data);
        // Handle success, e.g., display a success message
        setUsers((prevUsers) => prevUsers.filter((user) => user.id !== userId));
      })
      .catch((error) => {
        console.error(error);
        // Handle errors, e.g., display an error message
      });
  };

  return (
    <div>
      <h2>User List</h2>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {users.map((user) => (
            <tr key={user.id}>
              <td>{user.id}</td>
              <td>{user.f_name}</td>
              <td>{user.l_name}</td>
              <td>
                <button>Edit</button>
                <button onClick={() => handleDelete(user.id)}>Delete User</button>
                {/* Use an arrow function to prevent immediate invocation */}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default UserList;
