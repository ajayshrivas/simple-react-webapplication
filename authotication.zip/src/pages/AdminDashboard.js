import React from 'react';

const AdminDashboard = () => {
  return (
    <div>
      <h2>Admin Dashboard</h2>
      {/* Add your admin dashboard content here */}
    </div>
  );
};
export default AdminDashboard;