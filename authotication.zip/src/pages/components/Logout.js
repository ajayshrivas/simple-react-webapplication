import React from 'react';
const Logout = () => {
  // Handle the logout action
  const handleLogout = async () => {
    // Perform actions to log the user out
    // For example, clear session or token, etc.
    // Redirect to the login page or perform other actions as needed

    // Here, you can use a function to clear user data and session
    // For example, if you're using local storage for token-based authentication:

    // Clear the user's token from local storage
    localStorage.removeItem('userToken');

    // Redirect to the login page or any other desired action
    window.location.href = '/login'; // Replace with your login route

    // You can also clear any other user-related data or perform additional logout actions
  };

  return (
    <div>
      <h2>Logout</h2>
      <p>Are you sure you want to log out?</p>
      <button onClick={handleLogout}>Logout</button>
    </div>
  );
};
export default Logout;