import React, { useState } from 'react';
//import { useHistory } from 'react-router-dom';
import { useNavigate } from "react-router-dom";
const Login = () => {
  // Define state variables for user input
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });

  // Define state variable for error message
  const [error, setError] = useState('');

  // Handle input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const navigate = useNavigate();
  //const history = useHistory();
  // Handle form submission
  const handleLogin = async (e) => {
     e.preventDefault();

    // Send a POST request to your login API endpoint
  try {
        const response = await fetch('http://192.168.29.23:8000/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
          // Login was successful, store the token in localStorage
          const data = await response.json();
          localStorage.setItem('token', data.token);
          console.log('Login successful');

          // Redirect to the admin dashboard
          // window.location.href = '/admin'; // This will trigger the navigation to the admin route
           navigate("/admin");
      } else {
          // Login failed, display an error message
          const data = await response.json();
          setError(data.message || 'Login failed');
      }
    } catch (error) {
        console.error('Error:', error);
        setError('Login failed');
    }
  };
  
  return (
    <div>
      <h2>Login</h2>
      <form onSubmit={handleLogin}>
        <div>
          <label htmlFor="email">Email</label>
          <input
            type="text"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleInputChange}
          />
        </div>
        <div>
          <label htmlFor="password">Password</label>
          <input
            type="password"
            id="password"
            name="password"
            value={formData.password}
            onChange={handleInputChange}
          />
        </div>
        <div>
          <button type="submit">Login</button>
        </div>
      </form>
      {error && <p className="error">{error}</p>}
    </div>
  );
};
export default Login;