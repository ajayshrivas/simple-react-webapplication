import React, { useState } from 'react';

const Register = () => {
  // Define state variables for user input
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
  });

  // Define state variable for error message
  const [error, setError] = useState('');

  // Handle input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  // Handle form submission
  const handleRegistration = async (e) => {
    e.preventDefault();

    // Send a POST request to your registration API endpoint
    try {
      const response = await fetch('http://192.168.29.23:8000/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        // Registration was successful
        // You can redirect to the login page or display a success message
        console.log('Registration successful');
        
        setError('Registration successful');

      } else {
        // Registration failed, display an error message
        const data = await response.json();
        setError(data.message || 'Registration failed');
      }
    } catch (error) {
      console.error('Error:', error);
      setError('Registration failed');
    }
  };

  return (
    <div>
      <h2>Register</h2>
      <form onSubmit={handleRegistration}>
        <div>
          <label htmlFor="username">Username</label>
          <input
            type="text"
            id="username"
            name="username"
            value={formData.username}
            onChange={handleInputChange}
          />
        </div>
        <div>
          <label htmlFor="email">Email</label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleInputChange}
          />
        </div>
        <div>
          <label htmlFor="password">Password</label>
          <input
            type="password"
            id="password"
            name="password"
            value={formData.password}
            onChange={handleInputChange}
          />
        </div>
        <div>
          <button type="submit">Register</button>
        </div>
      </form>
      {error && <p className="error">{error}</p>}
    </div>
  );
};
export default Register;