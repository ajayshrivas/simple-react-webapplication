import { Link } from 'react-router-dom';
function Header(){
 return(
    <>
    <nav>
        <ul>
        <li>
            <Link to="/">Home</Link>
        </li>
        <li>
            <Link to="/blogs">Blogs</Link>
        </li>
        <li>
            <Link to="/contact">Contact</Link>
        </li>
        <li>
            <Link to="/UserList">User List</Link>
        </li>
        <li>
            <Link to="/FileUpload">File Send</Link>
        </li>
        <li>
            <Link to="/Authos">Authos</Link>
        </li>
        </ul>
    </nav>
    </>
    )
}
export default Header;