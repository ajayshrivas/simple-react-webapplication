import React, { useState, useEffect } from 'react';
const Blogs = () => {
  const [data, setData] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  useEffect(() => {
    fetch('https://jsonplaceholder.typicode.com/posts')
      .then(response => response.json())
      .then(data => {
        setData(data);
        console.log(data);
      })
      .catch(error => {
        console.error(error);
      });
  }, []);
  // Define a function to handle search input changes
  const handleSearchInputChange = event => {
    setSearchTerm(event.target.value);
  };
  const filteredData = data.filter(item =>
    item.title.toLowerCase().includes(searchTerm.toLowerCase())
  );
    return(
        <>
        <input
        type="text"
        placeholder="Search by title"
        value={searchTerm}
        onChange={handleSearchInputChange}
      />
        {filteredData.map(item => (
           <div key={item.id}>
            <h2>{item.title}</h2>
            <p>{item.body}</p>
           </div>
        ))}
        </>
        ); 
  };
  
  export default Blogs;