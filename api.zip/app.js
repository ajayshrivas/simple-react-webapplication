const express = require('express');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const crypto = require('crypto');
const cors = require('cors');
const mysql = require('mysql');
const app = express();
app.use(cors());

app.use(bodyParser.json());

const dbConnection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'node_db',
  }); 

// Replace this with your own secret key
// Generate a 32-character random secret key
const secretKey = crypto.randomBytes(32).toString('hex');

//console.log('Generated Secret Key:', secretKey);


// Dummy user data (replace this with a database)
const users = [];

// Middleware for JWT authentication
const authenticateJWT = (req, res, next) => {
  const token = req.headers.authorization;
  if (!token) return res.sendStatus(403);
  jwt.verify(token, secretKey, (err, user) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
};

// Route to register a new user
app.post('/register', async (req, res) => {
    const { username, password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
  
    // Insert the user into the database
    const insertQuery = 'INSERT INTO users (username, password) VALUES (?, ?)';
    dbConnection.query(insertQuery, [username, hashedPassword], (err, result) => {
      if (err) {
        console.error('Error registering user:', err);
        res.status(500).send('Error registering user');
      } else {
        res.status(201).send('User registered successfully');
      }
    });
});
  

// Route to log in and get a JWT
app.post('/login', async (req, res) => {
    console.log(req.body);
    const { email, password } = req.body;
    console.log(email);
    // Fetch the user from the database
    const selectQuery = 'SELECT * FROM users WHERE username = ?';
    dbConnection.query(selectQuery, [email], async (err, results) => {
      if (err) {
        console.error('Error retrieving user:', err);
        res.status(500).send('Error retrieving user');
      } else if (results.length === 0) {
        res.status(400).send('User not found');
      } else {
        const user = results[0];
        if (await bcrypt.compare(password, user.password)) {
          const token = jwt.sign({ email }, secretKey);
          return res.json({ token });
        } else {
          return res.status(401).send('Authentication failed');
        }
      }
    });
});

app.get('/',(req, res) => {
    res.send("Hello");
  });
// Route to access a protected resource
app.get('/protected', authenticateJWT, (req, res) => {
  res.json({ message: 'Protected resource' });
});


// Start the server
const port = 8000;
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
console.log('http://localhost:8000'); 